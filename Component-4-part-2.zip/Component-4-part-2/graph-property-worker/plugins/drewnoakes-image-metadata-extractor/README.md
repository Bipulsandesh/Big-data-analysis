# drew-noakes-image-metadata-extractor

This module extracts metadata contained in image files and create Lumify properties with those values. It also detects
if images need to be rotated and/or flipped in order to be displayed in the correct orientation.

See [Image and Video Processing](../../graph-property-worker/README-image-and-video-processing.md) for the required ontology
and lumify property configuration.
