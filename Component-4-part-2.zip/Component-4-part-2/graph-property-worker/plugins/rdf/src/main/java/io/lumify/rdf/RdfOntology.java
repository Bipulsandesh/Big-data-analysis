package io.lumify.rdf;

public class RdfOntology {
    public static final String MIME_TYPE_TEXT_RDF = "application/rdf+xml";
}
